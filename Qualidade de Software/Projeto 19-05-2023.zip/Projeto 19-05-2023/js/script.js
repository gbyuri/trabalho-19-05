addEventListener('load', function banner() {
    console.log("teste")
    document.querySelector('#img-1').checked = true;
    console.log(document.querySelector('#img-1').checked)
})


function checkbanner() {
    addEventListener('click', function check(){
       
    })
}